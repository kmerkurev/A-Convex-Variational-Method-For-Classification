function[uut] = General_CMF(P,G,n_classes,n_neighbors)

tic

%*** Segmentation of the data set into n_classes classes ***
%       
%
% Compile with 'mex CMF_mex_graph_multi_energy.c' before running 
%
% npoints: number of elements
% nclasses: number of classes
%
% Input P: npoints x number_of_attributes matrix,
%       G: ground truth vector (taking values 1 to nclasses)
%       n_classes:  # of classes
%       n_neighbors: # of nearest neighbors in the graph



% Output uut: simplex constrained labeling function arranged in size
%              npoints x nclass vector


          
npoints = size(P,1);


ns = createns(P,'nsmethod','kdtree');
[idx, dist] = knnsearch(ns,P,'k',n_neighbors,'distance','euclidean');


idx = reshape( idx(:,2:n_neighbors)' , 1, (n_neighbors-1)*npoints );



varParas = [npoints; n_neighbors-1; 300; 1e-400; 0.05; 0.025; n_classes ];
%                para 0 - number of points
%                para 1 - number of neighbors
%                para 2 - maximum number of iterations
%                para 3 - error criterion
%                para 4 - the step-size for the gradient-projection of p
%                para 5 - number of classes
%                para 6 - weight function

penalty = 0.5*ones(npoints,1);
dist(dist == 0) = 10^10;

weights = reshape( exp(-1*(dist(:,2:n_neighbors)))', 1, (n_neighbors-1)*npoints);



 for r=1:n_classes
     fCt(npoints*(r-1)+1:npoints*r) = 0;      % CODE UP the definition of fCt here
 end





% -------------------------------------------------------------------------
%  Uses the function CMF_mex_graph_multi_energy to run the algorithm on CPU
% -------------------------------------------------------------------------
 [uu, uut, isEdge, erriter,num,tt,E,Et,Et2,Eprimal,binary_difference] = CMF_mex_graph_multi_energy(single(penalty), single(fCt), single(weights'), uint64(idx'), single(varParas));

 
% -------------------------------------------------------------------------
%  Results
% -------------------------------------------------------------------------
                  
                  
                  
 F= zeros(npoints,1);
 uut = reshape(uut,npoints,n_classes);
 
  for i=1:npoints
      [~, argmax] = max(uut(i,:));
      F(i,1)= argmax;
  end

  accuracy=0;
  
  for i=1:npoints
      if (G(i,1) == F(i,1))
         accuracy= accuracy+1;
      end
  end
      


 toc
 
