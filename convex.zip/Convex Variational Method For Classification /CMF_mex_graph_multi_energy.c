/***************************************************************************/
/*      Name:       CMF_mex_graph_multi_energy.c
 *                  labeling of point cloud using max-flow
*/
/***************************************************************************/
/*  compilation command (under matlab): mex CMF_mex.c  */

#include <stdio.h>
#include <stdlib.h>
#include <mex.h>
#include <math.h>
#include <time.h>


#define YES 0
#define NO 1

#define PI 3.1415926

#define MAX(a,b) ( a > b ? a : b )
#define MIN(a,b) ( a <= b ? a : b )
#define SIGN(x) ( x >= 0.0 ? 1.0 : -1.0 )
#define ABS(x) ( (x) > 0.0 ? x : -(x) )
#define SQR(x) (x)*(x)

#ifndef HAVE_RINT 
#define rint(A) floor((A)+(((A) < 0)? -0.5 : 0.5)) 
#endif

float SQRT(float number) {
    long i;
    float x, y;
    const float f = 1.5F;
    
    x = number * 0.5F;
    y  = number;
    i  = * ( long * ) &y;
    i  = 0x5f3759df - ( i >> 1 );
    y  = * ( float * ) &i;
    y  = y * ( f - ( x * y * y ) );
    y  = y * ( f - ( x * y * y ) );
    return number * y;
}


/**********************************************/
/************** MAIN FUNCTION *****************/
/**********************************************/

/****************************************/
extern void mexFunction(int iNbOut, mxArray *pmxOut[],
int iNbIn, const mxArray *pmxIn[])
{
    
  /* iNbOut: number of outputs
     pmxOut: array of pointers to output arguments */
    
  /* iNbIn: number of inputs
     pmxIn: array of pointers to input arguments */
    
    
    float   *pfpenalty, *pfu, *pfut, *pfCs, *pfCt, *pfcvg, *pfVecParameters, *isEdge, *pfE, *pfEt, *pfEt2, *pfEprimal, *binary_difference;
    float   *pfps, *pfpt, *pfgk, *tt, *pfdv, *temp, *pfW, *pfp;
    float   fLambda, fError, cc, steps, max, min;
    float   fpt, fps, pfpsum;
    int     *punum, n_neighbors, iNdim, i, j, r, iNI, iN, nneighbors, value1, value2, n;
    int     iNbIters, index, indexj, kk, index_max, index_min, index_i, index_j;
    uint64_T *IDx;
    time_t  start_time, end_time;
    
    mwSize iDim[3];
    
    
    /* Inputs */
    pfpenalty = mxGetData(pmxIn[0]); /* Given penalty */
    pfCt = mxGetData(pmxIn[1]); /* bound of sink flows */
    pfW = mxGetData(pmxIn[2]);
    IDx = (uint64_T *)mxGetData(pmxIn[3]);
    pfVecParameters = mxGetData(pmxIn[4]); /* Vector of parameters */
    
    /* 
     *pfVecParameters Setting
     * [0] : number of points
     * [1] : number of neighbors
     * [2] : the maximum iteration number
     * [3] : error criterion
     * [4] : cc for the step-size of ALM
     * [5] : steps for the step-size of projected-gradient of p
     */
    
    /* Size */
    iN = (int) pfVecParameters[0];
    nneighbors = (int) pfVecParameters[1];
    n_neighbors = nneighbors;
    iNbIters = (int) pfVecParameters[2]; 
    fError = (float) pfVecParameters[3]; 
    cc = (float) pfVecParameters[4];
    steps = (float) pfVecParameters[5];
    n = (float) pfVecParameters[6];
    
    
    //mexPrintf("Reached 1 \n");
    

    //mexPrintf("In is %i", iN);
    //mexPrintf("nneighbors is %i", nneighbors);

    /* Outputs */
    /* outputs the computed u(x)  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iN*n;
    pmxOut[0] = mxCreateNumericArray(iNdim,iDim ,mxSINGLE_CLASS,mxREAL);
    pfu = mxGetData(pmxOut[0]);
  

    
    /* Outputs */
    /* outputs the computed u(x)  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iN*n;
    
    pmxOut[1] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    pfut = mxGetData(pmxOut[1]);

    
    /* outputs the computed isEdge  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iN*nneighbors;

    pmxOut[2] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    isEdge = mxGetData(pmxOut[2]);
   
    
    /* outputs the convergence rate  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iNbIters;

    pmxOut[3] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    pfcvg = mxGetData(pmxOut[3]);
    

    
    
    
    /* outputs the iteration number  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = 1;
    pmxOut[4] = mxCreateNumericArray(iNdim,iDim,mxUINT16_CLASS,mxREAL);
    punum = mxGetData(pmxOut[4]);
    
    /* outputs the computation time  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = 1;
    pmxOut[5] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    tt = mxGetData(pmxOut[5]);

    /* outputs the energy evolution  */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iNbIters;
    pmxOut[6] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    pfE = mxGetData(pmxOut[6]);
    
    /* outputs the energy evolution after threshold */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iNbIters;
    pmxOut[7] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    pfEt = mxGetData(pmxOut[7]);
    
    /* outputs the energy evolution after threshold */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iNbIters;
    pmxOut[8] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    pfEt2 = mxGetData(pmxOut[8]);
    
    
    /* outputs the energy evolution after threshold */
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iNbIters;
    pmxOut[9] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    pfEprimal = mxGetData(pmxOut[9]);
    
    iNdim = 2;
    iDim[0] = 1;
    iDim[1] = iNbIters;
    pmxOut[10] = mxCreateNumericArray(iNdim,iDim,mxSINGLE_CLASS,mxREAL);
    binary_difference = mxGetData(pmxOut[10]);
    
    
    
    
    /* Memory allocation */
    
    /* allocate the memory for temp */
    temp = (float *) calloc( (unsigned) (iN*n), sizeof(float) );
    if (!temp)
        mexPrintf("Memory allocation failure\n");

    /* allocate the memory for ps */
    pfps = (float *) calloc( (unsigned) (iN), sizeof(float) );
    if (!pfps)
        mexPrintf("Memory allocation failure\n");

    pfp = (float *) calloc((unsigned) (iN*nneighbors*n), sizeof(float) );
    if (!pfp)
        mexPrintf("Memory allocation failure\n");
    
    /* allocate the memory for pt */
    pfpt = (float *) calloc( (unsigned)(iN*n), sizeof(float) );
    if (!pfpt)
        mexPrintf("Memory allocation failure\n");
    
    // mexPrintf("Reached 3 \n");
    
//         /* allocate the memory for pfut */
//     pfut = (float *) calloc( (unsigned)(iN*n), sizeof(float) );
//     if (!pfpt)
//         mexPrintf("Memory allocation failure\n");
    
    /* allocate the memory for gk */
    pfgk = (float *) calloc( (unsigned)(iN), sizeof(float) );
    if (!pfgk)
        mexPrintf("Memory allocation failure\n");
    
    /* allocate the memory for div */
    pfdv = (float *) calloc( (unsigned) (iN*n), sizeof(float) );
    if (!pfdv)
        mexPrintf("Memory allocation failure\n");


    /* Preparing initial values for flows and u */


    for(r=0; r< n; r++){
        index_i = iN*r;
      for(i=0; i< iN; i++){

        pfps[i] = pfCt[index_i];
        if(pfCt[index_i+i] < pfps[i]){
                pfps[i] = pfCt[index_i+i];
        }
      }
    }

      for(r=0; r< n; r++){
          
        //mexPrintf("test");
          index_i = iN*r;
          for(i=0; i< iN; i++){
              if( pfps[i] == pfCt[index_i + i]){
                  pfu[index_i + i] = 1.f;
              }
                index = n_neighbors*i;
                pfpt[index_i + i] = pfps[i];
                index_j = r*iN*n_neighbors + i*n_neighbors;
                for (j=0; j<n_neighbors; j++){
                    pfp[index_j + j] = 0.f;
                    pfdv[index_i + i] = pfdv[index_i + i] + 2*pfp[index_j + j]*pfW[index + j];
                }
            }
        }

    /*  Main iterations */

    iNI = 0;

    start_time = clock();



    
    while( iNI<iNbIters ){
        /* update p */



     for(r=0; r< n; r++){
         index_i = iN*r;
        for (i=0; i<iN; i++) {
            temp[index_i + i] = pfps[i] - pfpt[index_i + i] + pfu[index_i + i]/cc;
            temp[index_i + i] = pfdv[index_i + i] - temp[index_i + i];
        }
     }




     for(r=0; r< n; r++){
         index_i = iN*r;
        for (i=0; i<iN; i++) {
            index_j = r*iN*n_neighbors + i*n_neighbors;
            index = n_neighbors*i;
            for (j=0; j<n_neighbors; j++){
                pfp[index_j + j] = pfp[index_j + j] + (temp[index_i + IDx[index + j]-1] - temp[index_i + i])*steps*pfW[index + j];
                pfpsum += pfp[index_j + j];
            }
        }
     }




        /* projection step */



     for(r=0; r< n; r++){
         index_i = iN*r;
        for (i=0; i< iN; i++)   {
            index = n_neighbors*i;
            index_j = r*iN*n_neighbors + i*n_neighbors;
            for (j=0; j< n_neighbors; j++) {
                   if (ABS(pfp[index_j+j])>pfW[index + j]){
                       pfp[index_j + j]= (float) pfW[index + j]*SIGN(pfp[index_j + j]);
                       if( pfW[index + j] == 0.f )
                           pfp[index_j + j] = 0.f;
                   }
             }
        }
     }



        /* compute the divergence  */
     for(r=0; r< n; r++){
         index_i = iN*r;
        for (i = 0; i < iN; i++){
            index_j = r*iN*n_neighbors + i*n_neighbors;
            pfdv[index_i+i] = 0;
            for (j=0; j< n_neighbors; j++){
                pfdv[index_i+i] = pfdv[index_i+i] + 2*pfp[index_j + j];       //  pfbx[index+iNy] - pfbx[index]
                                                               //+ pfby[index+1] - pfby[index];
            }
        }
     }


        /* update ps  */


        for (i = 0; i < iN; i++){
            fpt = 0;
            for(r=0; r< n; r++){
                index_i = iN*r;
                fpt = fpt + pfpt[index_i+i] - pfu[index_i+i]/cc + pfdv[index_i+i];

            }
            pfps[i] = fpt/n + 1/(cc*n);
        }


        
        /* update pt  */
     for(r=0; r< n; r++){
        index_i = iN*r;
        for (i = 0; i < iN; i++){
                fpt = pfps[i] + pfu[index_i+i]/cc - pfdv[index_i+i];
                fpt = MIN(fpt , pfCt[index_i+i]);
                pfpt[index_i+i] = fpt;
        }
     }
    
     /* update multipliers */
     for(r=0; r< n; r++){
        index_i = iN*r;
        fps = 0;
        for (i = 0; i < iN; i++){
                fpt = cc*(pfpt[index_i+i] + pfdv[index_i+i] - pfps[i]);
                fps += ABS(fpt);
                pfu[index_i+i] -= fpt;
        }
     }

     pfE[iNI] = 0.f;
     for(r=0; r< n; r++){
        index_i = iN*r;
        fps = 0;

        for (i = 0; i < iN; i++){
            index_j = r*iN*n_neighbors + i*n_neighbors;
            index = n_neighbors*i;
            pfE[iNI] = pfE[iNI] + pfu[index_i+i]*pfCt[index_i+i];
                for (j=0; j<n_neighbors; j++){
                    pfE[iNI] = pfE[iNI] + ABS(pfu[index_i + IDx[index + j]-1] - pfu[index_i + i])*pfW[index + j];
                }
        }
     }
     
        for (i = 0; i < iN; i++){
            max = 0.0;
            index_max = 0;
            for(r=0; r<n; r++){
                index_i = iN*r;
                if( pfu[index_i + i] > max){
                    index_max = index_i + i;
                    max = pfu[index_i + i];
                }
            }
            for(r=0; r<n; r++){
                index_i = iN*r;
                if(index_i + i == index_max)
                    pfut[index_i + i] = 1.f;
                else
                    pfut[index_i + i] = 0.f;
            }
        }
     
     pfEt[iNI] = 0.f;
     for(r=0; r< n; r++){
        index_i = iN*r;
        fps = 0;
        for (i = 0; i < iN; i++){
            index_j = r*iN*n_neighbors + i*n_neighbors;
            index = n_neighbors*i;
            pfEt[iNI] = pfEt[iNI] + pfut[index_i+i]*pfCt[index_i+i];
                for (j=0; j<n_neighbors; j++){
                    pfEt[iNI] = pfEt[iNI] + ABS(pfut[index_i + IDx[index + j]-1] - pfut[index_i + i])*pfW[index + j];
                }

        }
     }    
     
          //Threshold 2
       for (i = 0; i < iN; i++){
            min = 100000.f;
            index_min = 0;
            for(r=0; r<n; r++){
                index_i = iN*r;
                
                if( pfdv[index_i+i] + pfCt[index_i+i]  < min){
                    index_min = index_i + i;
                    min = pfdv[index_i+i] + pfCt[index_i+i];
                }
            }
            for(r=0; r<n; r++){
                index_i = iN*r;
                if(index_i + i == index_min)
                    pfut[index_i + i] = 1.f;
                else
                    pfut[index_i + i] = 0.f;
            }
        }
     

     
     pfEt2[iNI] = 0.f;
     for(r=0; r< n; r++){
        index_i = iN*r;
        fps = 0;
        for (i = 0; i < iN; i++){
            index_j = r*iN*n_neighbors + i*n_neighbors;
            index = n_neighbors*i;
            pfEt2[iNI] = pfEt2[iNI] + pfut[index_i+i]*pfCt[index_i+i];
                for (j=0; j<n_neighbors; j++){
                    pfEt2[iNI] = pfEt2[iNI] + ABS(pfut[index_i + IDx[index + j]-1] - pfut[index_i + i])*pfW[index + j];
                }

        }
     }  
     
                for (i = 0; i < iN; i++){
            min = 100000.f;
            index_min = 0;
            for(r=0; r<n; r++){
                index_i = iN*r;
                if( pfdv[index_i+i] + pfCt[index_i+i] < min){
                    index_min = index_i + i;
                    min = pfdv[index_i+i] + pfCt[index_i+i];
                }
            }
            for(r=0; r<n; r++){ 
                index_i = iN*r;
                if(index_i + i == index_min)
                    pfut[index_i + i] = 1.f;
                else
                    pfut[index_i + i] = 0.f;
            }
        }
     
     pfEprimal[iNI] = 0.f;
     binary_difference[iNI] = 0.f;
     
        for (i = 0; i < iN; i++){
            pfEprimal[iNI] = pfEprimal[iNI] + pfps[i];
            binary_difference[iNI] = binary_difference[iNI] + ABS(pfu[i]-pfut[i]);
            

        }

     
     

     
     pfcvg[iNI] = fps / iN;



     iNI ++;
     }



    
           for (i = 0; i < iN; i++){
            min = 100000.f;
            index_min = 0;
            for(r=0; r<n; r++){
                index_i = iN*r;
                if( pfdv[index_i+i] + pfCt[index_i+i] < min){
                    index_min = index_i + i;
                    min = pfdv[index_i+i] + pfCt[index_i+i];
                }
            }
            for(r=0; r<n; r++){ 
                index_i = iN*r;
                if(index_i + i == index_min)
                    pfut[index_i + i] = 1.f;
                else
                    pfut[index_i + i] = 0.f;
            }
        }


    for (i=0; i< iN; i++){
        index = n_neighbors*i;
        for (j=0; j<n_neighbors; j++){
             isEdge[index + j] = 0.f;
        }
    }




    for (i=0; i< iN; i++){
        index = n_neighbors*i;
        for (j=0; j<n_neighbors; j++){
                r=1;

                index_i = iN*r;
                index_j = r*iN*n_neighbors + i*n_neighbors;
                if( pfut[index_i + i] == pfut[MAX(index_i + IDx[index + j]-1,0)] ){
                    isEdge[index + j] = 1.f;
                }
            }
        }


    /* Outputs (see above) */

    punum[0] = iNI;

    /* Free memory */

    free( (float *) temp );
    free( (float *) pfps );
    free( (float *) pfpt );
    free( (float *) pfgk );
    free( (float *) pfdv );
    free( (float *) pfp  );

    end_time = clock();
    tt[0] = (float) difftime(end_time, start_time)/1000;



    //mexPrintf("\nComputing Time for CMF = %.4f sec\n \n", tt[0]);


}
/****************************************/




